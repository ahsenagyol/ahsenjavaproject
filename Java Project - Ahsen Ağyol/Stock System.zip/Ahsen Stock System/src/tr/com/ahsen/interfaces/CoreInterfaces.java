package tr.com.ahsen.interfaces;

import java.sql.Connection;

public interface CoreInterfaces {

	public Connection getConnection();
	
}