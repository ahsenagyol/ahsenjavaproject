package tr.com.ahsen.interfaces;

import java.util.List;

import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public interface DALInterfaces<T> {

	void Insert (T entity);
	List<T> GetAll();
	T Delete(T entity);
	void Update(T entity);
	List<T> GetById(int id);
	List<CategoryContract> GetAllParentId();
	void Insert1(ProductsContract entity);
	
	
}
