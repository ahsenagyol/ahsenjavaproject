package tr.com.ahsen.interfaces;

import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;

public interface FeInterfaces {

	public void initPencere() ; 
	public JPanel initPanel() ;
	public JMenuBar initBar() ;
	public JTabbedPane initTabs() ;
	
	
	
}
