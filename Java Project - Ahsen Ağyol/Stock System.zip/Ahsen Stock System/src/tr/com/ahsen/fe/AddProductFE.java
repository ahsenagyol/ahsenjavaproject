package tr.com.ahsen.fe;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.border.Border;

import com.toedter.calendar.JDateChooser;

import tr.com.ahsen.dal.CategoryDAL;
import tr.com.ahsen.dal.ProductsDAL;
import tr.com.ahsen.interfaces.FeInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public class AddProductFE extends JDialog implements FeInterfaces {

	public AddProductFE() {
		initPencere();
	}

	@Override
	public void initPencere() {
		JPanel panel = initPanel1();
		
		panel.setBorder(BorderFactory.createTitledBorder("Product Registration Area"));
		add(panel);
		setTitle ("Add Product");
		pack();
		setModalityType(DEFAULT_MODALITY_TYPE);
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(HIDE_ON_CLOSE);
			
		
	}
	
	public JPanel initPanel1() {
		JPanel panel = new JPanel(new GridLayout(5, 2));
		JLabel nameLabel = new JLabel("Product Name:",JLabel.RIGHT);	
		panel.add(nameLabel);
		JTextField nameField = new JTextField(10);
		panel.add(nameField);
		JLabel categoryLabel = new JLabel ("Select Category:",JLabel.RIGHT);
		panel.add(categoryLabel);
		JComboBox categoryBox = new JComboBox(new CategoryDAL().GetAll().toArray());
		panel.add(categoryBox);
		JLabel dateLabel = new JLabel ("Select Date:",JLabel.RIGHT);
		panel.add(dateLabel);
		JDateChooser dateDate = new JDateChooser ();
		panel.add(dateDate);
		JLabel priceLabel = new JLabel ("Enter Price:",JLabel.RIGHT);
		panel.add(priceLabel);
		JTextField priceField = new JTextField (10);
		panel.add(priceField);
		
		JButton saveButton = new JButton ("Save");
		panel.add(saveButton);
		JButton cancel = new JButton ("Cancel");
		panel.add(saveButton);
		saveButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
			ProductsContract contract = new ProductsContract();
			CategoryContract casContract = (CategoryContract) categoryBox.getSelectedItem();
			SimpleDateFormat format = new SimpleDateFormat ("yyyy-MMMM-dd");
				
			String date =  format.format(dateDate.getDate());
			contract.setName(nameField.getText());
			contract.setCategoryId(casContract.getId());
			contract.setDate(date);
			contract.setPrice(Float.parseFloat(priceField.getText()));
			new ProductsDAL().Insert(contract);
			JOptionPane.showMessageDialog(null, contract.getId()+"the product named has been successfully added.");
				
			}
		});
		
		return panel;
	}

	@Override
	public JMenuBar initBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JTabbedPane initTabs() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JPanel initPanel() {
		// TODO Auto-generated method stub
		return null;
	}

}
