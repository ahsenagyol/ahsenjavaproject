package tr.com.ahsen.fe;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;

import tr.com.ahsen.dal.CategoryDAL;
import tr.com.ahsen.interfaces.FeInterfaces;
import tr.com.ahsen.types.CategoryContract;

public class AddCategoryFE extends JDialog implements FeInterfaces{

	public AddCategoryFE() {
		initPencere();
	}

	@Override
	public void initPencere() {
		JPanel panel = initPanel();
		panel.setBorder(BorderFactory.createTitledBorder("Add Category"));
		
		add(panel);
		setTitle("Add Category");
		pack();
		setModalityType(DEFAULT_MODALITY_TYPE);
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(HIDE_ON_CLOSE);
		
		
	}

	@Override
	public JPanel initPanel() {
		
		
		JPanel panel = new JPanel (new GridLayout(3, 2));
		
		
		
		JLabel nameLabel = new JLabel("Category Name:",JLabel.RIGHT);
		panel.add(nameLabel);
		JTextField nameField = new JTextField (10);
		panel.add(nameField);
		JLabel categoryLabel = new JLabel("Select Category:",JLabel.RIGHT);
		panel.add(categoryLabel);
		JComboBox categoryBox = new JComboBox (new CategoryDAL().GetAllParentId().toArray());
		panel.add(categoryBox);
		categoryBox.insertItemAt("--Select Category--", 0);
		categoryBox.setSelectedIndex(0);
		JButton saveButton = new JButton ("Save");
		panel.add(saveButton);
		saveButton.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				CategoryContract contract = new CategoryContract();
				
				
				if(categoryBox.getSelectedIndex()!=0) {
					CategoryContract casContract = (CategoryContract) categoryBox.getSelectedItem();
					contract.setName(nameField.getText());
					contract.setParentId(casContract.getId());
					
					new CategoryDAL().Insert(contract);
					JOptionPane.showMessageDialog(null ,contract.getName() + "the Category named has been successfully added.");
						
				}else
					contract.setName(nameField.getText());
					contract.setParentId(categoryBox.getSelectedIndex());
					
					new CategoryDAL().Insert(contract);
					
					JOptionPane.showMessageDialog(null ,contract.getName() + "the Category named has been successfully added.");
				
			}
		});
		
		JButton cancelButton = new JButton ("Cancel");
		panel.add(cancelButton);
		
		
		return panel;
	}

	@Override
	public JMenuBar initBar() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public JTabbedPane initTabs() {
		// TODO Auto-generated method stub
		return null;
	}

}
