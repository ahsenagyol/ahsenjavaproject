package tr.com.ahsen.fe;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JTabbedPane;
import javax.swing.JMenuItem;

import tr.com.ahsen.interfaces.FeInterfaces;
import tr.com.ahsen.utilities.MenuCom;

public class MainWindowFE extends JFrame implements FeInterfaces {
	
	public MainWindowFE () {
		initPencere();
	}

	
	@Override
	public void initPencere() {
		//JTabbedPane tabs = initTabs();
		JMenuBar bar = initBar();

		//add(tabs);
		setJMenuBar(bar);
		setTitle("Sales and Stock Program");
		setSize(600, 250);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);	
		
	}

	@Override
	public JPanel initPanel() {
		JPanel panel = initPanel ();
		JMenuBar bar = initBar();
		
		add(panel);
		setJMenuBar(bar);
		setTitle("Sales and Stock Program");
		setExtendedState(MAXIMIZED_BOTH);
		// setUndecorated(true);
		setVisible(true);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		
	
			
		
		
		
		return panel;
	}

	@Override
	public JMenuBar initBar() {
		JMenuBar bar = MenuCom.initBar();
		
		
		
		
		return bar;
	}

	@Override
	public JTabbedPane initTabs() {
		// TODO Auto-generated method stub
		return null;
	}

}
