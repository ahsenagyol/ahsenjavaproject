package tr.com.ahsen.utilities;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JMenu;
import javax.swing.JMenuItem;
import javax.swing.SwingUtilities;
import javax.swing.JMenuBar;

import tr.com.ahsen.fe.AddCategoryFE;
import tr.com.ahsen.fe.AddPersonnelFE;
import tr.com.ahsen.fe.AddProductFE;

public class MenuCom {

	public static JMenuBar initBar() {
		JMenuBar bar = new JMenuBar ();
		
		
		JMenu fileMenu = new JMenu ("File");
		bar.add(fileMenu);
		JMenuItem exitItem = new JMenuItem("Exit");
		fileMenu.add(exitItem);
		/*Products Menu*/
		JMenu productsMenu = new JMenu ("Products");
		bar.add(productsMenu);
		JMenuItem addProductItem = new JMenuItem ("Add Product");
		productsMenu.add(addProductItem);
		JMenuItem addCategoryItem = new JMenuItem ("Add Category");
		productsMenu.add(addCategoryItem);
		productsMenu.addSeparator();
		JMenuItem editProductItem = new JMenuItem ("Edit Product");
		productsMenu.add(editProductItem);
		JMenuItem editCategoryItem = new JMenuItem ("Edit Category");
		productsMenu.add(editCategoryItem);
		/*Personnel Menu*/
		JMenu personnelsMenu = new JMenu("Personnels:");
		bar.add(personnelsMenu);
		JMenuItem addPersonnelItem = new JMenuItem("Add Personnel");
		productsMenu.add(personnelsMenu);
		JMenuItem addAuthorityItem = new JMenuItem("Add Authority");
		productsMenu.add(addAuthorityItem);
		JMenuItem setPasswordItem = new JMenuItem("Set Password");
		productsMenu.add(setPasswordItem);
		personnelsMenu.addSeparator();
		
		JMenuItem editPersonnelItem = new JMenuItem("Edit Personnel");
		productsMenu.add(editPersonnelItem);
		JMenuItem editAuthority = new JMenuItem("Edit Authority"); 
		productsMenu.add(editAuthority);
		JMenuItem editPasswordItem = new JMenuItem("Edit Password");
		personnelsMenu.add(editPasswordItem);
		
		
		
		
		addProductItem.addActionListener((ActionListener) new ActionListener() {
			
		
			@Override
			public void actionPerformed(ActionEvent e) {
				SwingUtilities.invokeLater(new Runnable() {
					
					@Override
					public void run() {
						new AddProductFE();
					}	
				});
			}
			
		});
		
		addCategoryItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new AddCategoryFE();
				
			}
		});
			
		addPersonnelItem.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				
				SwingUtilities.invokeLater(new Runnable() {
					
					@Override
					public void run() {
						
						new AddPersonnelFE();
						
						
					}
				});
				
			}
		});
		
		return bar;
					
	}					
}
					