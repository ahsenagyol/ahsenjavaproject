package tr.com.ahsen.dal;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;

import tr.com.ahsen.core.ObjectHelper;
import tr.com.ahsen.interfaces.DALInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public class ProductsDAL extends ObjectHelper implements DALInterfaces<ProductsContract> {

	public void Insert11(ProductsContract entity) {
		
		Connection connection = getConnection();
		
		
		try {
			Statement statement = connection.createStatement();
			statement.executeUpdate("INSERT INTO Products (Name, CategoryId,Date,Price) " 
			+ "VALUES('"
			+entity.getName()
			+"'," 
			+ entity.getCategoryId()
			+",'" 
			+ entity.getDate()
				+"'," + entity.getPrice() + ")") ;
			statement.close();
			statement.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		  
		
		
	}

	@Override
	public List<ProductsContract> GetAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ProductsContract Delete(ProductsContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<ProductsContract> GetById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryContract> GetAllParentId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Insert(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void Insert1(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}
	
	
	

}
 