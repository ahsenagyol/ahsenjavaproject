package tr.com.ahsen.dal;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import tr.com.ahsen.core.ObjectHelper;
import tr.com.ahsen.interfaces.DALInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract; 

public class CategoryDAL extends ObjectHelper implements DALInterfaces<CategoryContract> {

	@Override
	public void Insert(CategoryContract entity) {
		
		Connection connection = getConnection();
		try {
			Statement statement = (Statement) connection.createStatement();
			
			((java.sql.Statement) statement).executeUpdate("INSERT INTO Category (Name, ParentId) VALUES('" + entity.getName() + "',"
					+ entity.getParentId() + ")");
		((Connection) statement).close();
			connection.close();
		}catch (SQLException e) {
			//TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<CategoryContract> GetAll() {
		
		List<CategoryContract> datacontract = new ArrayList<CategoryContract> (); 
		Connection connection = (Connection) getConnection();
		CategoryContract contract;
		try {
			java.sql.Statement statement = connection.createStatement();
			ResultSet resultSet = statement.executeQuery("SELECT * FROM Category");
			while(resultSet.next()) {
				contract = new CategoryContract ();
				contract.setId(resultSet.getInt("Id"));
				contract.setName(resultSet.getString("Name"));
				contract.setParentId(resultSet.getInt("ParentId"));
	
				datacontract.add(contract);
				
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return datacontract;
	}

	public CategoryContract Delete1(CategoryContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	public void Update1(CategoryContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CategoryContract> GetById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CategoryContract Delete(CategoryContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(CategoryContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<CategoryContract> GetAllParentId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Insert1(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

	
	
	

}
