package tr.com.ahsen.dal;

import java.util.List;

import tr.com.ahsen.core.ObjectHelper;
import tr.com.ahsen.interfaces.DALInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public class AutorithyDAL <YetkilerContract> extends ObjectHelper implements DALInterfaces <YetkilerContract> {

	@Override
	public void Insert(YetkilerContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<YetkilerContract> GetAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public YetkilerContract Delete(YetkilerContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(YetkilerContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<YetkilerContract> GetById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryContract> GetAllParentId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Insert1(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

}
