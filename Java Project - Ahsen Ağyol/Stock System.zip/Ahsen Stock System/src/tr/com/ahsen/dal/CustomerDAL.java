package tr.com.ahsen.dal;

import java.util.List;

import tr.com.ahsen.core.ObjectHelper;
import tr.com.ahsen.interfaces.DALInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public class CustomerDAL <MusteriContract> extends ObjectHelper implements DALInterfaces <MusteriContract> {

	@Override
	public void Insert(MusteriContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MusteriContract> GetAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public MusteriContract Delete(MusteriContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(MusteriContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<MusteriContract> GetById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryContract> GetAllParentId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Insert1(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

}
