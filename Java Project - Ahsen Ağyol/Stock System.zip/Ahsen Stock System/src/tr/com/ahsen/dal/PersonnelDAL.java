package tr.com.ahsen.dal;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import tr.com.ahsen.core.ObjectHelper;
import tr.com.ahsen.fe.AddPersonnelFE;
import tr.com.ahsen.interfaces.DALInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public class PersonnelDAL <PersonelContract> extends ObjectHelper implements DALInterfaces <PersonelContract> {

	@Override
	public void Insert(PersonelContract entity) {
		Connection connection = getConnection();
		try {
			Statement statement = (Statement) connection.createStatement();
			
			((java.sql.Statement) statement).executeUpdate("INSERT INTO Category (NameSurname, Email) "
					+ "VALUES('" 
					+ ((AddPersonnelFE) entity).getName()
					+ "',"
					+ ((AddPersonnelFE) entity).getEmail() + "')");
		((Connection) statement).close();
			connection.close();
		}catch (SQLException e) {
			//TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	@Override
	public List<PersonelContract> GetAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonelContract Delete(PersonelContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(PersonelContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<PersonelContract> GetById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryContract> GetAllParentId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Insert1(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

}
