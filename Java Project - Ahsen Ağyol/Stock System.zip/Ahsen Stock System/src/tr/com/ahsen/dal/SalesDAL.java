package tr.com.ahsen.dal;

import java.util.List;

import tr.com.ahsen.core.ObjectHelper;
import tr.com.ahsen.interfaces.DALInterfaces;
import tr.com.ahsen.types.CategoryContract;
import tr.com.ahsen.types.ProductsContract;

public class SalesDAL <SatisContract> extends ObjectHelper implements DALInterfaces <SatisContract> {

	@Override
	public void Insert(SatisContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<SatisContract> GetAll() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SatisContract Delete(SatisContract entity) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Update(SatisContract entity) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<SatisContract> GetById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CategoryContract> GetAllParentId() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void Insert1(ProductsContract entity) {
		// TODO Auto-generated method stub
		
	}

}
