package tr.com.ahsen.types;

public class PersonnelContract {

	private static final int NameSurname = 0;
	private static final int Email = 0;
	private int id;
	private String nameSurname;
	private String email;

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNameSurname() {
		return getNameSurname();
	}
	public void setNameSurname(String nameSurname) {
		this.nameSurname = nameSurname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return id + " " + NameSurname + " " + Email; 
	}
	
	
}
