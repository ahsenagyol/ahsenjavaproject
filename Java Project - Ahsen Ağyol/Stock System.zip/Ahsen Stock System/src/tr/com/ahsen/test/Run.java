package tr.com.ahsen.test;

import javax.swing.SwingUtilities;

import tr.com.ahsen.fe.MainWindowFE;

public class Run {
	
	public static void main(String[] args) {
		
		SwingUtilities.invokeLater(new Runnable() {

			@Override
			public void run() {
				
				new MainWindowFE();
				
			}
		});;	
		
	}
 
}
